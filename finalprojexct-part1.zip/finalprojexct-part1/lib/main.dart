import 'dart:html';

import 'package:finalprojexct/screens/SignupScreen.dart';
import 'package:finalprojexct/screens/Splash.dart';
import 'package:finalprojexct/screens/authentication.dart';
import 'package:finalprojexct/screens/opening.dart';
import 'package:finalprojexct/themes/darkmode.dart';
import 'package:finalprojexct/themes/lightmode.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'screens/LoginScreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

void_liveLocation(){
  var LocationAccuracy;
  LoactionSettings locationSettings= const LoactionSettings(
    accuracy: LocationAccuracy.high,
    distanceFilter:100,
  );

  var Geolocator;
  Geolocator.getPositionstream(locationSettings:locationSettings)
    .listen((Position position){
      var lat = position.latitude.toString();
      var long=position.longitude.toString();

      setState((){
        locationMessage='Latitude:$lat, Longitude: $long';
      });
    });
}

url_launcher: ^6.1.2
Future<void> _openMap(String lat, String long) async{
  String googleURL='https://www.google.com/maps/search/?api-1&query-$lat,$long';
  
  await canLaunchURLString(googleURL)
  ? await launchURLString(googleURL)
  :throw 'could not launch $googleURL';
}
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MessageMe',
      theme: lightTheme,
      darkTheme: darkTheme,
      home: const SplashScreen(), // Set the splash screen as the home
  Text(locationMessage, textAlign : TextAlign.center),
  String locationMessage = 'Current Location';
  late.string.lat;
  late.string.long;
   Future<Position> _getCurrentLocation() async{
    bool serviceEnabled = await Geolocator,isLocaionServiceEnabled();
    if (!serviceEnabled){
      return Future.error("location disabled");
    }
    LocationPermission pemission = await Geolocator.checkPermission();
    if (permission== LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LoactionPermission.denied) {
        return Future.error (Loaction permission denied);
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return Future.error(actions:
          'Location permission are permenately denied')
    }
    return await Geolocator.getCurrentPosition();
   }

  ElevatedButton(
    onpressed: () {
      _getCurrentLocation().then((value) {
        lat = '${value.latitude}';
        long = '${value.longitude}';
        setState(().{
          locationMessage= 'Latitude:$lat,Longitude:.$long';
        });
        _liveLocation();
      });
    },
    child: const Text("click to get current location"),
    ),
    ElevatedButton(
      onPressed:(){
        _openMap(lat,long);
      },
      child:const Text('open map')
    ),

    );
  }
}

canLaunchURLString(String googleURL) {
}

launchURLString(googleURL) {
}

