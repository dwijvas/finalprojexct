package com.example.finalprojexct;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
